<?php

/**
 * 	@autor Xinergia
 * 	@version 1.0	20/11/2020
 * 	Manager de Programas de salud.
 *
 */
class ManagerProgramaSalud extends ManagerMedia {

    /** constructor
     * 	@param $db instancia de adodb
     */
    function __construct($db) {

        // Llamamos al constructor del a superclase
        parent::__construct($db, "programa_salud", "idprograma_salud");
        $this->setImgContainer("programa_salud");
        $this->addImgType("png");
        $this->addThumbConfig(50, 50, "_perfil");
        $this->addThumbConfig(150, 150, "_usuario");
        $this->addThumbConfig(110, 110, "_list");
    }

    public function getListadoJSON($request, $idpaginate = NULL) {

        if (!is_null($idpaginate)) {
            $this->paginate($idpaginate, 20);
        }

        $query = new AbstractSql();
        $query->setSelect("
                *
            ");
        $query->setFrom("
                $this->table 
            ");

        // Filtro
        if ($request["programa_salud"] != "") {

            $rdo = cleanQuery($request["programa_salud"]);

            $query->addAnd("programa_salud LIKE '%$rdo%'");
        }


        $data = $this->getJSONList($query, array("programa_salud"), $request, $idpaginate);

        return $data;
    }

    /**
     * Método que devuelve un registro 
     * @param type $id
     */
    public function get($id) {
        $record = parent::get($id);
        $imagenes = $this->getImagenes($id);
        $record["imagen"] = $imagenes["imagen"];
        $record["icon"] = $imagenes["icon"];
        return $record;
    }

    /**
     * Metodo que devuelve un array con lsa imagenes de la entidad
     * @param type $id
     * @return boolean
     */
    public function getImagenes($id) {


        if (is_file(path_entity_files("{$this->imgContainer}/$id/$id.png"))) {

            $imagen["imagen"] = array(
                "original" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}.png",
                "perfil" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_perfil.png",
                "list" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_list.png",
                "usuario" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_usuario.png"
            );
        }

        if (is_file(path_entity_files("{$this->imgContainer}/$id/icon.png"))) {

            $imagen["icon"] = array(
                "original" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/icon.png",
                "perfil" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/icon_perfil.png",
                "list" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/icon_list.png",
                "usuario" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/icon_usuario.png"
            );
        }

        return $imagen;
    }

    /**
     * Metodo que devuelve el listao completo de programas de salud con sus imagenes correspondientes
     * @return type
     */
    public function getListadoProgramas() {
        $query = new AbstractSql();
        $query->setSelect("
                *
            ");
        $query->setFrom("
                $this->table 
            ");
        $query->setOrderBy("orden ASC");
        $listado = $this->getList($query);

        //recorremos el listado y agregamos las imagenes
        foreach ($listado as $key => $item) {
            $listado[$key]["imagenes"] = $this->getImagenes($item[$this->id]);
        }
        return $listado;
    }

}

//END_class
?>