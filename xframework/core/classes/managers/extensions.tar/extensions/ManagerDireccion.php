<?php

/**
 * 	Manager de Direccion
 *
 * 	@author UTN
 * 	@version 1.0
 * 	@package managers\extensions
 */
class ManagerDireccion extends ManagerMaestros {

    /** constructor
     * 	@param $db instancia de adodb
     */
    function __construct($db) {

        // Constructor
        parent::__construct($db, "direccion", "iddireccion");
    }

    /**
     * Obtiene un registro de dirección
     * @param int $id identificador de la dirección 
     * @return array 
     * 
     */
    public function get($id) {

        $direccion = parent::get($id);

        if ($direccion) {

            $localidad = $this->getManager("ManagerLocalidad")->getFull($direccion["localidad_idlocalidad"]);

            if ($localidad) {
                $direccion = array_merge($direccion, $localidad);
            }
        }

        return $direccion;
    }

    /**
     * Metodo que proces la direccion del consultorio.  Se asocia al medico y a sus consultorios
     * @param type $request
     */
    public function processDireccionMedico($request) {

        $idmedico = $_SESSION[URL_ROOT][CONTROLLER]["logged_account"]["medico"]["idmedico"];
        $ManagerMedico = $this->getManager("ManagerMedico");
        $ManagerConsultorio = $this->getManager("ManagerConsultorio");

        //obtenemos info del medico previamente para comparar la actualizacion de datos
        $info_medico = $ManagerMedico->getInfoMenuMedico($idmedico);

        //limpiamos el telefono del formato del plugin
        $request["telefono"] = str_replace(" ", "", $request["telefono"]);
        $request["telefono"] = str_replace("-", "", $request["telefono"]);
        $this->db->StartTrans();

        //guardamos los datos
        $id = parent::process($request);

        if (!$id) {
            $this->setMsg(["result" => false, "msg" => "Ha ocurrido un error."]);
            $this->db->FailTrans();
            $this->db->CompleteTrans();
            return false;
        }

        $direccion["direccion_iddireccion"] = $id;
        //asociamos la direccion del consulorio
        $list_consultorios = $ManagerConsultorio->getListconsultorioMedico($idmedico);

        foreach ($list_consultorios as $consultorio) {

            $upd_consultorio = $ManagerConsultorio->update($direccion, $consultorio["idconsultorio"]);
            if (!$upd_consultorio) {
                $this->setMsg(["result" => false, "msg" => "Ha ocurrido un error."]);
                $this->db->FailTrans();
                $this->db->CompleteTrans();
                return false;
            }
        }
        //asociamos la direccion al médico
        $upd_medicos = $ManagerMedico->basic_update($direccion, $idmedico);
        if (!$upd_medicos) {
            $this->setMsg(["result" => false, "msg" => "Ha ocurrido un error."]);
            $this->db->FailTrans();
            $this->db->CompleteTrans();
            return false;
        }

        //verificamos si compelto los datos minimos requeridos

        $showModal = false;

        // completo la direccion -> Hacemos la consulta de los datos restantes
        if ($info_medico["consultorio_virtual"]["idconsultorio"] != "" && //tiene consultorio virtual
                $info_medico["medico"]["direccion_iddireccion"] == "" && //NO tenia direccion seteada antes
                $info_medico["medico"]["preferencia"]["valorPinesVideoConsultaTurno"] != "") { //tiene precio VC seteados
            // En este caso forzamos a mostrar el modal.
            $showModal = true;
        }
        
        $this->setMsg(["result" => true, "msg" => "Datos guardados con éxito", "showModal" => $showModal]);
        $this->db->CompleteTrans();
        return $id;
    }

}

//END_class 
?>