<?php

/**
 * 	@autor Xinergia
 * 	@version 1.0	20/11/2020
 * 	Manager de Categorias de Programas de salud.
 *
 */
class ManagerProgramaSaludCategoria extends ManagerMedia {

    /** constructor
     * 	@param $db instancia de adodb
     */
    function __construct($db) {

        // Llamamos al constructor del a superclase
        parent::__construct($db, "programa_categoria", "idprograma_categoria");
        $this->setImgContainer("programa_categoria");
        $this->addImgType("svg");
        $this->addThumbConfig(50, 50, "_perfil");
        $this->addThumbConfig(150, 150, "_usuario");
        $this->addThumbConfig(110, 110, "_list");
    }

    public function getListadoJSON($request, $idpaginate = NULL) {
        if (!is_null($idpaginate)) {
            $this->paginate($idpaginate, 20);
        }

        $query = new AbstractSql();
        $query->setSelect("
                *
            ");
        $query->setFrom("
                $this->table 
            ");
        $query->setWhere("programa_salud_idprograma_salud=" . $request["idprograma_salud"]);

        // Filtro
        if ($request["programa_categoria"] != "") {

            $rdo = cleanQuery($request["programa_categoria"]);

            $query->addAnd("programa_categoria LIKE '%$rdo%'");
        }

        $data = $this->getJSONList($query, array("programa_categoria"), $request, $idpaginate);

        return $data;
    }

    /**
     * Método que devuelve un registro 
     * @param type $id
     */
    public function get($id) {
        $record = parent::get($id);
        $record["imagen"] = $this->getImagenes($id);
        return $record;
    }

    /**
     * Metodo que devuelve un array con lsa imagenes de la entidad
     * @param type $id
     * @return boolean
     */
    public function getImagenes($id) {


        if (is_file(path_entity_files("{$this->imgContainer}/$id/$id.png"))) {

            $imagen = array(
                "original" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}.png",
                "perfil" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_perfil.png",
                "list" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_list.png?",
                "usuario" => URL_ROOT . "xframework/files/entities/{$this->imgContainer}/$id/{$id}_usuario.png"
            );

            return $imagen;
        } else {

            return false;
        }
    }

    /**
     * Metodo que devuelve el listao completo de categorias de programas salud con sus imagenes correspondientes
     * @return type
     */
    public function getListadoCategorias($idprograma_salud) {
        $query = new AbstractSql();
        $query->setSelect("
                *
            ");
        $query->setFrom("
                $this->table 
            ");
        $query->setWhere("programa_salud_idprograma_salud={$idprograma_salud}");
        $query->setOrderBy("orden ASC");
        $listado = $this->getList($query);

        //recorremos el listado y agregamos las imagenes
        foreach ($listado as $key => $item) {
            $listado[$key]["imagenes"] = $this->getImagenes($item[$this->id]);
        }
        return $listado;
    }
}

//END_class
